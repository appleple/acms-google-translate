<?php

namespace Acms\Plugins\GoogleTranslate\Exceptions;

use Exception;

class NotFoundException extends Exception
{
}
